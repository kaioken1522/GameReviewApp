package com.example.gamereview;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class ReadReviewPage extends Fragment {

    RecyclerView recyclerView;
    RecyclerView.Adapter ReadReviewAdapter;
    RecyclerView.LayoutManager layoutManager;

    int[] proflePhotoList = {R.drawable.gameimage,R.drawable.gameimage2,R.drawable.gameimage};

    String[] description = {"this is the descriptionthis is the descriptionthis is the descriptionthis is the descriptionthis is the descriptionthis is the descriptionthis is the descriptionthis is the descriptionthis is the descriptionthis is the description","what is next?what is next?","what is next?what is next?what is next?"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_read_review_page, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.listGames);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(view.getContext());
        recyclerView.setLayoutManager(layoutManager);
        ReadReviewAdapter = new ReadReviewAdapter(view.getContext(),description,proflePhotoList);
        recyclerView.setAdapter(ReadReviewAdapter);
    }
}