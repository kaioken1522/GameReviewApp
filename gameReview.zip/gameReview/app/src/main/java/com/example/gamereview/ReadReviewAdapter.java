package com.example.gamereview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ReadReviewAdapter extends RecyclerView.Adapter<ReadReviewAdapter.ViewHolder> {
    Context context;
    String[] description;
    int[] proflePhotoList;

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView rowName;
        ImageView rowImage;

        public ViewHolder(@NonNull
                                  View itemView) {
            super(itemView);
            rowName = itemView.findViewById(R.id.textView);
            rowImage = itemView.findViewById(R.id.imageView);
        }
    }

    public ReadReviewAdapter(Context context, String[] description, int[] proflePhotoList){
        this.context = context;
        this.description = description;
        this.proflePhotoList = proflePhotoList;
    }

    @NonNull
    @Override
    public ReadReviewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.list_item_rrp, parent,false);
        ReadReviewAdapter.ViewHolder viewHolder = new ReadReviewAdapter.ViewHolder(view);
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull ReadReviewAdapter.ViewHolder holder, int position) {
        holder.rowName.setText(description[position]);
        holder.rowImage.setImageResource(proflePhotoList[position]);
    }


    @Override
    public int getItemCount() {
        return description.length;
    }
}

