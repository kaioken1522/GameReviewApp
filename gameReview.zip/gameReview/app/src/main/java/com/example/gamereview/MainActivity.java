package com.example.gamereview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        if(savedInstanceState == null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new login()).commit();
            navigationView.setCheckedItem(R.id.nav_loginPage);
        }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.nav_loginPage:
                getSupportActionBar().setTitle("Login");
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new login()).commit();

                break;
            case R.id.nav_userProfile:
                getSupportActionBar().setTitle("Profile");
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ProfilePage()).commit();
                break;
            case R.id.nav_gamePage:
                getSupportActionBar().setTitle("Games");
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new MainPage()).commit();
                break;
            case R.id.nav_readReview:
                getSupportActionBar().setTitle("Read Reviews");
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ReadReviewPage()).commit();
                break;
            case R.id.nav_writeReview:
                getSupportActionBar().setTitle("Write Review");
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new WriteReviewPage()).commit();
                break;
            case R.id.nav_logout:

                Toast.makeText(this, "Logout!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_signup:
                getSupportActionBar().setTitle("Signup");
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new signup()).commit();
                break;

        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }
}